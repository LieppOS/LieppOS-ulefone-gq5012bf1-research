/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2020 MediaTek Inc.
 */

#ifndef __LINUX_RT_TCPC_H
#define __LINUX_RT_TCPC_H

#include <linux/device.h>
#include <linux/hrtimer.h>
#include <linux/workqueue.h>
#include <linux/pm_wakeup.h>
#include <linux/err.h>
#include <linux/cpu.h>
#include <linux/delay.h>

#include "tcpci_core.h"
#include "pd_dbg_info.h"

#if IS_ENABLED(CONFIG_USB_POWER_DELIVERY)
#include "pd_core.h"
#endif /* CONFIG_USB_POWER_DELIVERY */

#define PE_STATE_FULL_NAME	0

#define TCPC_NORMAL_RP_DUTY	(308)		/* 30% */

#ifndef MIN
#define MIN(a, b)       (((a) < (b)) ? (a) : (b))
#endif

#ifdef CONFIG_SUPPORT_SOUTHCHIP_PDPHY
#define SOUTHCHIP_PD_VER    0X3116

/********************** product define *********************/
#define SOUTHCHIP_PD_VID	0x311C
#define SC2150_PID			0x2150
#define SC2150A_DID			0x0000
#define SC2150A_1P2_DID 	0x0001
#define SC2150P_DID			0x0003

#define SC660X_PID			0x6600
#define SC660X_DID			0x0000
/***********************************************************/
#endif /* CONFIG_SUPPORT_SOUTHCHIP_PDPHY */
#define TCPC_LOW_RP_DUTY		(100)		/* 10 % */

/* provide to TCPC interface */
extern int tcpci_report_usb_port_attached(struct tcpc_device *tcpc);
extern int tcpci_report_usb_port_detached(struct tcpc_device *tcpc);
extern int tcpci_report_usb_port_changed(struct tcpc_device *tcpc);
extern int tcpci_report_power_control(struct tcpc_device *tcpc, bool en);
extern int tcpc_typec_init(struct tcpc_device *tcpc, uint8_t typec_role);
extern void tcpc_typec_deinit(struct tcpc_device *tcpc);

extern struct tcpc_device *tcpc_device_register(
		struct device *parent, struct tcpc_desc *tcpc_desc,
		struct tcpc_ops *ops, void *drv_data);
extern void tcpc_device_unregister(
			struct device *dev, struct tcpc_device *tcpc);

extern int tcpc_schedule_init_work(struct tcpc_device *tcpc);

extern int tcpc_device_irq_enable(struct tcpc_device *tcpc);

extern void *tcpc_get_dev_data(struct tcpc_device *tcpc);
extern void tcpci_lock_typec(struct tcpc_device *tcpc);
extern void tcpci_unlock_typec(struct tcpc_device *tcpc);
extern int tcpci_alert(struct tcpc_device *tcpc, bool masked);

extern void tcpci_vbus_level_refresh(struct tcpc_device *tcpc);
int tcpci_alert_wakeup(struct tcpc_device *tcpc);

static inline int tcpci_check_vbus_valid(struct tcpc_device *tcpc)
{
	return tcpc->vbus_level >= TCPC_VBUS_VALID;
}

int tcpci_check_vbus_valid_from_ic(struct tcpc_device *tcpc);
bool tcpci_check_vsafe0v(struct tcpc_device *tcpc);
int tcpci_alert_status_clear(struct tcpc_device *tcpc, uint32_t mask);
int tcpci_fault_status_clear(struct tcpc_device *tcpc, uint8_t status);
int tcpci_set_alert_mask(struct tcpc_device *tcpc, uint32_t mask);
int tcpci_get_alert_mask(struct tcpc_device *tcpc, uint32_t *mask);
int tcpci_get_alert_status_and_mask(struct tcpc_device *tcpc, uint32_t *alert, uint32_t *mask);
int tcpci_get_fault_status(struct tcpc_device *tcpc, uint8_t *fault);
int tcpci_get_power_status(struct tcpc_device *tcpc);
int tcpci_init(struct tcpc_device *tcpc, bool sw_reset);
int tcpci_init_alert_mask(struct tcpc_device *tcpc);

int tcpci_get_cc(struct tcpc_device *tcpc);
int tcpci_is_plugged_in(struct tcpc_device *tcpc);
int tcpci_set_cc(struct tcpc_device *tcpc, int pull);
int tcpci_set_polarity(struct tcpc_device *tcpc, int polarity);
int tcpci_set_vconn(struct tcpc_device *tcpc, int enable);

int tcpci_set_low_power_mode(struct tcpc_device *tcpc, bool en);
int tcpci_alert_vendor_defined_handler(struct tcpc_device *tcpc);
int tcpci_set_auto_dischg_discnt(struct tcpc_device *tcpc, bool en);
int tcpci_get_vbus_voltage(struct tcpc_device *tcpc, u32 *vbus);
#ifdef CONFIG_SUPPORT_SOUTHCHIP_PDPHY
int tcpci_set_watchdog(struct tcpc_device *tcpc, bool en);
#endif /* CONFIG_SUPPORT_SOUTHCHIP_PDPHY */

#if CONFIG_WATER_DETECTION
int tcpci_set_water_protection(struct tcpc_device *tcpc, bool en);
int tcpci_notify_wd_status(struct tcpc_device *tcpc, bool water_detected);
#endif /* CONFIG_WATER_DETECTION */

int tcpci_notify_fod_status(struct tcpc_device *tcpc);
#if CONFIG_CABLE_TYPE_DETECTION
int tcpci_notify_cable_type(struct tcpc_device *tcpc);
#endif /* CONFIG_CABLE_TYPE_DETECTION */
int tcpci_notify_typec_otp(struct tcpc_device *tcpc);

int tcpci_set_cc_hidet(struct tcpc_device *tcpc, bool en);
#ifdef CONFIG_SUPPORT_SOUTHCHIP_PDPHY
int tcpci_notify_wd0_state(struct tcpc_device *tcpc, bool wd0_state, bool typec_port_stat);
#else
int tcpci_notify_wd0_state(struct tcpc_device *tcpc, bool wd0_state);
#endif
int tcpci_set_vbus_short_cc(struct tcpc_device *tcpc, bool cc1, bool cc2);
int tcpci_notify_vbus_short_cc_status(struct tcpc_device *tcpc, int vsc_status);

#if IS_ENABLED(CONFIG_USB_POWER_DELIVERY)

int tcpci_set_msg_header(struct tcpc_device *tcpc,
	uint8_t power_role, uint8_t data_role);

int tcpci_set_rx_enable(struct tcpc_device *tcpc, uint8_t enable);

int tcpci_protocol_reset(struct tcpc_device *tcpc);

int tcpci_get_message(struct tcpc_device *tcpc,
	uint32_t *payload, uint16_t *head, enum tcpm_transmit_type *type);

void tcpc_tx_pending_work_func(struct work_struct *work);

int tcpci_transmit(struct tcpc_device *tcpc,
	enum tcpm_transmit_type type, uint16_t header, const uint32_t *data);

int tcpci_set_bist_test_mode(struct tcpc_device *tcpc, bool en);

#if CONFIG_USB_PD_RETRY_CRC_DISCARD
int tcpci_retransmit(struct tcpc_device *tcpc);
#endif	/* CONFIG_USB_PD_RETRY_CRC_DISCARD */
#endif	/* CONFIG_USB_POWER_DELIVERY */

#ifdef CONFIG_SUPPORT_SOUTHCHIP_PDPHY
int tcpci_get_chip_id(struct tcpc_device *tcpc,uint32_t *chip_id);
int tcpci_get_chip_pid(struct tcpc_device *tcpc,uint32_t *chip_pid);
int tcpci_get_chip_vid(struct tcpc_device *tcpc,uint32_t *chip_vid);
#endif /* CONFIG_SUPPORT_SOUTHCHIP_PDPHY */

int tcpci_notify_typec_state(struct tcpc_device *tcpc);

int tcpci_notify_role_swap(
	struct tcpc_device *tcpc, uint8_t event, uint8_t role);
int tcpci_notify_pd_mode(struct tcpc_device *tcpc);
int tcpci_notify_pd_state(struct tcpc_device *tcpc, uint8_t connect);

int tcpci_source_vbus(struct tcpc_device *tcpc, uint8_t type, int mv, int ma);
int tcpci_sink_vbus(struct tcpc_device *tcpc, uint8_t type, int mv, int ma);
int tcpci_disable_vbus_control(struct tcpc_device *tcpc);
int tcpci_notify_attachwait_state(struct tcpc_device *tcpc, bool as_sink);
int tcpci_enable_io_boost(struct tcpc_device *tcpc, bool en);
int tcpci_enable_discharge(struct tcpc_device *tcpc, bool en, int mv);
int tcpci_notify_ps_change(struct tcpc_device *tcpc, int vbus_level);
int tcpci_notify_cc_hi(struct tcpc_device *tcpc, int cc_hi);
int tcpci_notify_alert_ratelimited(struct tcpc_device *tcpc, bool limited);

#if IS_ENABLED(CONFIG_USB_POWER_DELIVERY)

int tcpci_notify_hard_reset_state(struct tcpc_device *tcpc, uint8_t state);
int tcpci_notify_wait_new_cap(struct tcpc_device *tcpc);

int tcpci_enter_mode(struct tcpc_device *tcpc,
	uint16_t svid, uint8_t ops, uint32_t mode);
int tcpci_exit_mode(struct tcpc_device *tcpc, uint16_t svid);

int tcpci_report_hpd_state(struct tcpc_device *tcpc, uint32_t dp_status);
int tcpci_dp_status_update(struct tcpc_device *tcpc, uint32_t dp_status);
int tcpci_dp_configure(struct tcpc_device *tcpc, uint32_t dp_config);
int tcpci_dp_attention(struct tcpc_device *tcpc, uint32_t dp_status);

int tcpci_dp_notify_status_update_done(
	struct tcpc_device *tcpc, uint32_t dp_status, bool ack);

int tcpci_dp_notify_config_start(struct tcpc_device *tcpc);
int tcpci_dp_notify_config_done(struct tcpc_device *tcpc,
	uint32_t local_cfg, uint32_t remote_cfg, bool ack);

int tcpci_notify_cvdm(struct tcpc_device *tcpc, bool ack);

#if CONFIG_USB_PD_REV30

#if CONFIG_USB_PD_REV30_ALERT_REMOTE
int tcpci_notify_alert(struct tcpc_device *tcpc, uint32_t ado);
#endif	/* CONFIG_USB_PD_REV30_ALERT_REMOTE */

#if CONFIG_USB_PD_REV30_STATUS_REMOTE
int tcpci_notify_status(struct tcpc_device *tcpc, struct pd_status *sdb);
#endif	/* CONFIG_USB_PD_REV30_STATUS_REMOTE */

#if CONFIG_USB_PD_REV30_BAT_INFO
int tcpci_notify_request_bat_info(
	struct tcpc_device *tcpc, enum pd_battery_reference ref);
#endif	/* CONFIG_USB_PD_REV30_BAT_INFO */
#endif	/* CONFIG_USB_PD_REV30 */

#endif	/* CONFIG_USB_POWER_DELIVERY */

#endif /* #ifndef __LINUX_RT_TCPC_H */
