cmd_/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o := clang -Wp,-MMD,/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/.audio_messenger_ipi.o.d -nostdinc -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include -I./arch/arm64/include/generated -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include -I./include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi -I./arch/arm64/include/generated/uapi -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi -I./include/generated/uapi -include /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler-version.h -include /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kconfig.h -include /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DKASAN_SHADOW_SCALE_SHIFT= -Qunused-arguments -fmacro-prefix-map=/home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu11 --target=aarch64-linux-gnu -fintegrated-as -Werror=unknown-warning-option -Werror=ignored-optimization-argument -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -fasynchronous-unwind-tables -mbranch-protection=pac-ret -Wa,-march=armv8.5-a -DARM64_ASM_ARCH='"armv8.5-a"' -ffixed-x18 -DKASAN_SHADOW_SCALE_SHIFT= -fno-delete-null-pointer-checks -Wno-frame-address -Wno-address-of-packed-member -O2 -Wframe-larger-than=2048 -fstack-protector-strong -Wno-gnu -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fsanitize=kcfi -Wvla -Wno-pointer-sign -Wcast-function-type -Werror -Wimplicit-fallthrough -fno-strict-overflow -fno-stack-check -Werror=date-time -Werror=incompatible-pointer-types -Wno-initializer-overrides -Wno-sign-compare -Wno-pointer-to-enum-cast -Wno-tautological-constant-out-of-range-compare -Wno-unaligned-access -Wno-cast-function-type-strict -Wno-enum-compare-conditional -Wno-enum-enum-conversion -g -gdwarf-4 -D__ANDROID_COMMON_KERNEL__ -faddrsig -fmacro-prefix-map=/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/=../kernel_device_modules-6.1/ -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1592 -Werror -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/include/uapi -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/adsp/include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/scp/include -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/scp/rv -I/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/sound/soc/mediatek/audio_scp  -fsanitize=array-bounds -fsanitize=local-bounds -fsanitize-undefined-trap-on-error  -DMODULE  -DKBUILD_BASENAME='"audio_messenger_ipi"' -DKBUILD_MODNAME='"audio_messenger_ipi"' -D__KBUILD_MODNAME=kmod_audio_messenger_ipi -c -o /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.c  

source_/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o := /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.c

deps_/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o := \
    $(wildcard include/config/MTK_AUDIODSP_SUPPORT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler_attributes.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler-clang.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/CLANG_VERSION) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/compiler.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_messenger_ipi.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/types.h \
  arch/arm64/include/generated/uapi/asm/types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/int-ll64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/int-ll64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/posix_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/stddef.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/stddef.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/posix_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/posix_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_ipi_dma.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/rwonce.h \
    $(wildcard include/config/LTO) \
    $(wildcard include/config/AS_HAS_LDAPR) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/rwonce.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/err.h \
  arch/arm64/include/generated/uapi/asm/errno.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/errno.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/errno-base.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/errno.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/errno.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/overflow.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/limits.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/limits.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/limits.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/const.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/const.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/const.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/stdarg.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/string.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/string.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/fortify-string.h \
    $(wildcard include/config/KMSAN) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/bug.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/stringify.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/brk-imm.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
    $(wildcard include/config/SMP) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/once_lite.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/init.h \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
    $(wildcard include/config/STRICT_KERNEL_RWX) \
    $(wildcard include/config/STRICT_MODULE_RWX) \
    $(wildcard include/config/LTO_CLANG) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kern_levels.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/TRIM_UNUSED_KSYMS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/linkage.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/ratelimit_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/bits.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/bits.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/build_bug.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/param.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/param.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/param.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/spinlock_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/qrwlock_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/byteorder.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/byteorder/little_endian.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/byteorder/little_endian.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/swab.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/swab.h \
  arch/arm64/include/generated/uapi/asm/swab.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/swab.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/byteorder/generic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/spinlock.h \
    $(wildcard include/config/PREEMPTION) \
    $(wildcard include/config/PREEMPT_RT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/typecheck.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/cleanup.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/list.h \
    $(wildcard include/config/DEBUG_LIST) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/container_of.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/barrier.h \
    $(wildcard include/config/ARM64_PSEUDO_NMI) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/barrier.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/preempt.h \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/jump_label.h \
    $(wildcard include/config/JUMP_LABEL) \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/jump_label.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/insn.h \
    $(wildcard include/config/ARM64_LSE_ATOMICS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/insn-def.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/GENERIC_ENTRY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/HARDENED_USERCOPY) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/restart_block.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/time64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/math.h \
  arch/arm64/include/generated/asm/div64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/div64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/kernel.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/sysinfo.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/math64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/time64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/time.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/time_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/current.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/bitops.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/generic-non-atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/bitops.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/builtin-__ffs.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/builtin-ffs.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/builtin-__fls.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/builtin-fls.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/ffz.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/fls64.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/sched.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/hweight.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/arch_hweight.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/const_hweight.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/cmpxchg.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/lse.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/atomic_ll_sc.h \
    $(wildcard include/config/CC_HAS_K_CONSTRAINT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/alternative.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/alternative-macros.h \
  arch/arm64/include/generated/asm/cpucaps.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/atomic_lse.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/atomic/atomic-long.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/atomic/atomic-instrumented.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/instrumented.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kmsan-checks.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/instrumented-atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/lock.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/instrumented-lock.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/non-atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/non-instrumented-non-atomic.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/le.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/thread_info.h \
    $(wildcard include/config/ARM64_SW_TTBR0_PAN) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/memory.h \
    $(wildcard include/config/ARM64_VA_BITS) \
    $(wildcard include/config/KASAN_SHADOW_OFFSET) \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/ARM64_4K_PAGES) \
    $(wildcard include/config/KASAN_HW_TAGS) \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/EFI) \
    $(wildcard include/config/ARM_GIC_V3_ITS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/sizes.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/page-def.h \
    $(wildcard include/config/ARM64_PAGE_SHIFT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_IRQSOFF) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
    $(wildcard include/config/SPARSEMEM) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/pfn.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/stack_pointer.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/irqflags.h \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/irqflags.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/ptrace.h \
    $(wildcard include/config/COMPAT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/cpufeature.h \
    $(wildcard include/config/ARM64_PAN) \
    $(wildcard include/config/ARM64_SVE) \
    $(wildcard include/config/ARM64_SME) \
    $(wildcard include/config/ARM64_CNP) \
    $(wildcard include/config/ARM64_PTR_AUTH) \
    $(wildcard include/config/ARM64_MTE) \
    $(wildcard include/config/ARM64_DEBUG_PRIORITY_MASKING) \
    $(wildcard include/config/ARM64_BTI) \
    $(wildcard include/config/ARM64_TLB_RANGE) \
    $(wildcard include/config/ARM64_PA_BITS) \
    $(wildcard include/config/ARM64_HW_AFDBM) \
    $(wildcard include/config/ARM64_AMU_EXTN) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/cputype.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/sysreg.h \
    $(wildcard include/config/BROKEN_GAS_INST) \
    $(wildcard include/config/ARM64_PA_BITS_52) \
    $(wildcard include/config/ARM64_16K_PAGES) \
    $(wildcard include/config/ARM64_64K_PAGES) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kasan-tags.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/gpr-num.h \
  arch/arm64/include/generated/asm/sysreg-defs.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/bitfield.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/hwcap.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/hwcap.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/align.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kstrtox.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/minmax.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/instruction_pointer.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/ptrace.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/sve_context.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/percpu.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/percpu.h \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/percpu-defs.h \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/bottom_half.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/bitmap.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/find.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/gfp_types.h \
    $(wildcard include/config/CMA) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/numa.h \
    $(wildcard include/config/NODES_SHIFT) \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/smp_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/smp.h \
    $(wildcard include/config/ARM64_ACPI_PARKING_PROTOCOL) \
  arch/arm64/include/generated/asm/mmiowb.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/spinlock_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rwlock_types.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/spinlock.h \
  arch/arm64/include/generated/asm/qspinlock.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/qspinlock.h \
  arch/arm64/include/generated/asm/qrwlock.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/qrwlock.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/processor.h \
    $(wildcard include/config/KUSER_HELPERS) \
    $(wildcard include/config/ARM64_FORCE_52BIT) \
    $(wildcard include/config/HAVE_HW_BREAKPOINT) \
    $(wildcard include/config/ARM64_PTR_AUTH_KERNEL) \
    $(wildcard include/config/ARM64_TAGGED_ADDR_ABI) \
    $(wildcard include/config/GCC_PLUGIN_STACKLEAK) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/cache.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/kasan-enabled.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/static_key.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/mte-def.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/android_vendor.h \
    $(wildcard include/config/ANDROID_VENDOR_OEM_DATA) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/android_kabi.h \
    $(wildcard include/config/ANDROID_KABI_RESERVE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/processor.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/vdso/processor.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/hw_breakpoint.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/virt.h \
    $(wildcard include/config/KVM) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/sections.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/sections.h \
    $(wildcard include/config/HAVE_FUNCTION_DESCRIPTORS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/kasan.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/mte-kasan.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/pgtable-types.h \
    $(wildcard include/config/PGTABLE_LEVELS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/pgtable-nopud.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/pgtable-nop4d.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/pgtable-hwdef.h \
    $(wildcard include/config/ARM64_CONT_PTE_SHIFT) \
    $(wildcard include/config/ARM64_CONT_PMD_SHIFT) \
    $(wildcard include/config/ARM64_VA_BITS_52) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/pointer_auth.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/prctl.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/once.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/random.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/ioctl.h \
  arch/arm64/include/generated/uapi/asm/ioctl.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/ioctl.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/asm-generic/ioctl.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/irqnr.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/irqnr.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/prandom.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/percpu.h \
    $(wildcard include/config/NEED_PER_CPU_EMBED_FIRST_CHUNK) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/archrandom.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/arm-smccc.h \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/HAVE_ARM_SMCCC) \
    $(wildcard include/config/ARM) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/spectre.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/fpsimd.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/uapi/asm/sigcontext.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rwlock.h \
    $(wildcard include/config/PREEMPT) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/sound/soc/mediatek/audio_scp/scp_audio_ipi.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/adsp/include/adsp_helper.h \
    $(wildcard include/config/MTK_USB_OFFLOAD) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/notifier.h \
    $(wildcard include/config/TREE_SRCU) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/mutex.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/osq_lock.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/debug_locks.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/SRCU) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rcupdate.h \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/RCU_STRICT_GRACE_PERIOD) \
    $(wildcard include/config/RCU_LAZY) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/KVM_XFER_TO_GUEST_WORK) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/context_tracking_irq.h \
    $(wildcard include/config/CONTEXT_TRACKING_IDLE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rcutree.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/ktime.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/time.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/time32.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/timex.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/timex.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/timex.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/arch/arm64/include/asm/arch_timer.h \
    $(wildcard include/config/ARM_ARCH_TIMER_OOL_WORKAROUND) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/clocksource/arm_arch_timer.h \
    $(wildcard include/config/ARM_ARCH_TIMER) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/timecounter.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/asm-generic/timex.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/time32.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/time.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/jiffies.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/jiffies.h \
  include/generated/timeconst.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/vdso/ktime.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/timekeeping.h \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/clocksource_ids.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rcu_segcblist.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/srcutree.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/completion.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/swait.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/linux/wait.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/common/include/uapi/linux/wait.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/adsp_ipi_queue.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_log.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_assert.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_task.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_ipi_queue.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_ipi_platform.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_ipi_platform_common.h \
  /home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/include/audio_playback_msg_id.h \

/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o: $(deps_/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o)

$(deps_/home/armol/kernel-work/platform-batch-04-cleancheck/ws/src/kdm/drivers/misc/mediatek/audio_ipi/common/audio_messenger_ipi.o):
#SYMVER audio_send_ipi_msg 0x4862e694
#SYMVER audio_send_ipi_buf_to_dsp 0xd04d732f
#SYMVER audio_recv_ipi_buf_from_dsp 0xa8d0aa80
