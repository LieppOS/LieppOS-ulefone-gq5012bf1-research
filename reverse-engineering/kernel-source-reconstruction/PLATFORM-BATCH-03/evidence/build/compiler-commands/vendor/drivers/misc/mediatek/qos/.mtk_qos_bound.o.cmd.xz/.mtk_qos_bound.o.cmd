cmd_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o := clang -Wp,-MMD,/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/.mtk_qos_bound.o.d -nostdinc -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include -I./arch/arm64/include/generated -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include -I./include -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi -I./arch/arm64/include/generated/uapi -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi -I./include/generated/uapi -include /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler-version.h -include /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kconfig.h -include /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DKASAN_SHADOW_SCALE_SHIFT= -Qunused-arguments -fmacro-prefix-map=/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu11 --target=aarch64-linux-gnu -fintegrated-as -Werror=unknown-warning-option -Werror=ignored-optimization-argument -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -fasynchronous-unwind-tables -mbranch-protection=pac-ret -Wa,-march=armv8.5-a -DARM64_ASM_ARCH='"armv8.5-a"' -ffixed-x18 -DKASAN_SHADOW_SCALE_SHIFT= -fno-delete-null-pointer-checks -Wno-frame-address -Wno-address-of-packed-member -O2 -Wframe-larger-than=2048 -fstack-protector-strong -Wno-gnu -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fsanitize=kcfi -Wvla -Wno-pointer-sign -Wcast-function-type -Werror -Wimplicit-fallthrough -fno-strict-overflow -fno-stack-check -Werror=date-time -Werror=incompatible-pointer-types -Wno-initializer-overrides -Wno-sign-compare -Wno-pointer-to-enum-cast -Wno-tautological-constant-out-of-range-compare -Wno-unaligned-access -Wno-cast-function-type-strict -Wno-enum-compare-conditional -Wno-enum-enum-conversion -g -gdwarf-4 -D__ANDROID_COMMON_KERNEL__ -faddrsig -fmacro-prefix-map=/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/=../kernel_device_modules-6.1/ -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1592 -Werror -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include/uapi -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/sspm/v3 -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/tinysys_scmi -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos  -fsanitize=array-bounds -fsanitize=local-bounds -fsanitize-undefined-trap-on-error  -DMODULE  -DKBUILD_BASENAME='"mtk_qos_bound"' -DKBUILD_MODNAME='"mtk_qos"' -D__KBUILD_MODNAME=kmod_mtk_qos -c -o /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.c  

source_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o := /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.c

deps_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o := \
    $(wildcard include/config/MTK_TINYSYS_SSPM_V2) \
    $(wildcard include/config/MTK_TINYSYS_SCMI) \
    $(wildcard include/config/MTK_DRAMC) \
    $(wildcard include/config/MTK_EMI) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler_attributes.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler-clang.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/CLANG_VERSION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/compiler.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/io.h \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/HAS_IOPORT_MAP) \
    $(wildcard include/config/PCI) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/types.h \
  arch/arm64/include/generated/uapi/asm/types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/int-ll64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/int-ll64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/posix_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/stddef.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/stddef.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/posix_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/posix_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/init.h \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
    $(wildcard include/config/STRICT_KERNEL_RWX) \
    $(wildcard include/config/STRICT_MODULE_RWX) \
    $(wildcard include/config/LTO_CLANG) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/rwonce.h \
    $(wildcard include/config/LTO) \
    $(wildcard include/config/AS_HAS_LDAPR) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/rwonce.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/bug.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/stringify.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/brk-imm.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
    $(wildcard include/config/SMP) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/once_lite.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/stdarg.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kern_levels.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/TRIM_UNUSED_KSYMS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/linkage.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/ratelimit_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/const.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/const.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/const.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/bits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/build_bug.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/param.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/param.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/param.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/spinlock_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/qrwlock_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/byteorder.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/byteorder/little_endian.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/byteorder/little_endian.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/swab.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/swab.h \
  arch/arm64/include/generated/uapi/asm/swab.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/swab.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/byteorder/generic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/err.h \
  arch/arm64/include/generated/uapi/asm/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/errno-base.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/io.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/pgtable.h \
    $(wildcard include/config/PGTABLE_LEVELS) \
    $(wildcard include/config/HIGHPTE) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/ARCH_HAS_NONLEAF_PMD_YOUNG) \
    $(wildcard include/config/GUP_GET_PTE_LOW_HIGH) \
    $(wildcard include/config/HAVE_ARCH_TRANSPARENT_HUGEPAGE_PUD) \
    $(wildcard include/config/HAVE_ARCH_SOFT_DIRTY) \
    $(wildcard include/config/ARCH_ENABLE_THP_MIGRATION) \
    $(wildcard include/config/ARCH_HAS_PTE_DEVMAP) \
    $(wildcard include/config/NUMA_BALANCING) \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMAP) \
    $(wildcard include/config/X86_ESPFIX64) \
    $(wildcard include/config/HUGETLB_PAGE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/pfn.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/pgtable.h \
    $(wildcard include/config/ARM64_PA_BITS_52) \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/ARM64_64K_PAGES) \
    $(wildcard include/config/PAGE_TABLE_CHECK) \
    $(wildcard include/config/ARM64_MTE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/proc-fns.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/page.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/page-def.h \
    $(wildcard include/config/ARM64_PAGE_SHIFT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/personality.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/personality.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/pgtable-types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/pgtable-nopud.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/pgtable-nop4d.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/memory.h \
    $(wildcard include/config/ARM64_VA_BITS) \
    $(wildcard include/config/KASAN_SHADOW_OFFSET) \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/ARM64_4K_PAGES) \
    $(wildcard include/config/KASAN_HW_TAGS) \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/EFI) \
    $(wildcard include/config/ARM_GIC_V3_ITS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/sizes.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bitops.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/typecheck.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/kernel.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/sysinfo.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/generic-non-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/barrier.h \
    $(wildcard include/config/ARM64_PSEUDO_NMI) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/barrier.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/bitops.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-__ffs.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-ffs.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-__fls.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-fls.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/ffz.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/fls64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/sched.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/hweight.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/arch_hweight.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/const_hweight.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/cmpxchg.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/lse.h \
    $(wildcard include/config/ARM64_LSE_ATOMICS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/atomic_ll_sc.h \
    $(wildcard include/config/CC_HAS_K_CONSTRAINT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/alternative.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/alternative-macros.h \
  arch/arm64/include/generated/asm/cpucaps.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/insn-def.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/atomic_lse.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic/atomic-long.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic/atomic-instrumented.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/instrumented.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kmsan-checks.h \
    $(wildcard include/config/KMSAN) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/instrumented-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/lock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/instrumented-lock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/non-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/non-instrumented-non-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/le.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM_IRQSOFF) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
    $(wildcard include/config/SPARSEMEM) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/getorder.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/mte.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/mte-def.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bitfield.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kasan-enabled.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/static_key.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/jump_label.h \
    $(wildcard include/config/JUMP_LABEL) \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/jump_label.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/insn.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/page-flags.h \
    $(wildcard include/config/ARCH_USES_PG_UNCACHED) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HUGETLB_PAGE_OPTIMIZE_VMEMMAP) \
    $(wildcard include/config/HIGHMEM) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/KSM) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/mm_types.h \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/MEMCG) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/PER_VMA_LOCK) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
    $(wildcard include/config/PREEMPT_RT) \
    $(wildcard include/config/IOMMU_SVA) \
    $(wildcard include/config/LRU_GEN) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/mm_types_task.h \
    $(wildcard include/config/SPLIT_PTLOCK_CPUS) \
    $(wildcard include/config/ARCH_ENABLE_SPLIT_PMD_PTLOCK) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/align.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/limits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/limits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/limits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/container_of.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kstrtox.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/math.h \
  arch/arm64/include/generated/asm/div64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/div64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/minmax.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/instruction_pointer.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bitmap.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/find.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/overflow.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/string.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/string.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/fortify-string.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/gfp_types.h \
    $(wildcard include/config/CMA) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/numa.h \
    $(wildcard include/config/NODES_SHIFT) \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/auxvec.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/auxvec.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/auxvec.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kref.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/spinlock.h \
    $(wildcard include/config/PREEMPTION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/preempt.h \
    $(wildcard include/config/PREEMPT_COUNT) \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/cleanup.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/list.h \
    $(wildcard include/config/DEBUG_LIST) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/preempt.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/GENERIC_ENTRY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/HARDENED_USERCOPY) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/restart_block.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/time64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/math64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/time64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/time.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/time_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/current.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/thread_info.h \
    $(wildcard include/config/ARM64_SW_TTBR0_PAN) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/stack_pointer.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/irqflags.h \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/irqflags.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/ptrace.h \
    $(wildcard include/config/COMPAT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/cpufeature.h \
    $(wildcard include/config/ARM64_PAN) \
    $(wildcard include/config/ARM64_SVE) \
    $(wildcard include/config/ARM64_SME) \
    $(wildcard include/config/ARM64_CNP) \
    $(wildcard include/config/ARM64_PTR_AUTH) \
    $(wildcard include/config/ARM64_DEBUG_PRIORITY_MASKING) \
    $(wildcard include/config/ARM64_BTI) \
    $(wildcard include/config/ARM64_TLB_RANGE) \
    $(wildcard include/config/ARM64_PA_BITS) \
    $(wildcard include/config/ARM64_HW_AFDBM) \
    $(wildcard include/config/ARM64_AMU_EXTN) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/cputype.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/sysreg.h \
    $(wildcard include/config/BROKEN_GAS_INST) \
    $(wildcard include/config/ARM64_16K_PAGES) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kasan-tags.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/gpr-num.h \
  arch/arm64/include/generated/asm/sysreg-defs.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/hwcap.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/hwcap.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/ptrace.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/sve_context.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/percpu.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/percpu.h \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/percpu-defs.h \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bottom_half.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/smp_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/smp.h \
    $(wildcard include/config/ARM64_ACPI_PARKING_PROTOCOL) \
  arch/arm64/include/generated/asm/mmiowb.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/spinlock_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rwlock_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/spinlock.h \
  arch/arm64/include/generated/asm/qspinlock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/qspinlock.h \
  arch/arm64/include/generated/asm/qrwlock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/qrwlock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/processor.h \
    $(wildcard include/config/KUSER_HELPERS) \
    $(wildcard include/config/ARM64_FORCE_52BIT) \
    $(wildcard include/config/HAVE_HW_BREAKPOINT) \
    $(wildcard include/config/ARM64_PTR_AUTH_KERNEL) \
    $(wildcard include/config/ARM64_TAGGED_ADDR_ABI) \
    $(wildcard include/config/GCC_PLUGIN_STACKLEAK) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/cache.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/android_vendor.h \
    $(wildcard include/config/ANDROID_VENDOR_OEM_DATA) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/android_kabi.h \
    $(wildcard include/config/ANDROID_KABI_RESERVE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/processor.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/vdso/processor.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/hw_breakpoint.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/virt.h \
    $(wildcard include/config/KVM) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/sections.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/sections.h \
    $(wildcard include/config/HAVE_FUNCTION_DESCRIPTORS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/kasan.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/mte-kasan.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/pgtable-hwdef.h \
    $(wildcard include/config/ARM64_CONT_PTE_SHIFT) \
    $(wildcard include/config/ARM64_CONT_PMD_SHIFT) \
    $(wildcard include/config/ARM64_VA_BITS_52) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/pointer_auth.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/prctl.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/once.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/random.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/ioctl.h \
  arch/arm64/include/generated/uapi/asm/ioctl.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/ioctl.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/ioctl.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/irqnr.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/irqnr.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/prandom.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/percpu.h \
    $(wildcard include/config/NEED_PER_CPU_EMBED_FIRST_CHUNK) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/archrandom.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/arm-smccc.h \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/HAVE_ARM_SMCCC) \
    $(wildcard include/config/ARM) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/spectre.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/fpsimd.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/sigcontext.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rwlock.h \
    $(wildcard include/config/PREEMPT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/refcount.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rbtree.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rbtree_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rcupdate.h \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/RCU_STRICT_GRACE_PERIOD) \
    $(wildcard include/config/RCU_LAZY) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/KVM_XFER_TO_GUEST_WORK) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/context_tracking_irq.h \
    $(wildcard include/config/CONTEXT_TRACKING_IDLE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rcutree.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/maple_tree.h \
    $(wildcard include/config/MAPLE_RCU_DISABLED) \
    $(wildcard include/config/DEBUG_MAPLE_TREE_VERBOSE) \
    $(wildcard include/config/DEBUG_MAPLE_TREE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/osq_lock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/completion.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/swait.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/wait.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/wait.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/uprobes.h \
    $(wildcard include/config/UPROBES) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/uprobes.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/debug-monitors.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/esr.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/probes.h \
    $(wildcard include/config/KPROBES) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/page-flags-layout.h \
  include/generated/bounds.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/sparsemem.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/ktime.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/time.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/time32.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/timex.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/timex.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/timex.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/arch_timer.h \
    $(wildcard include/config/ARM_ARCH_TIMER_OOL_WORKAROUND) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/clocksource/arm_arch_timer.h \
    $(wildcard include/config/ARM_ARCH_TIMER) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/timecounter.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/timex.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/time32.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/time.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/jiffies.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/jiffies.h \
  include/generated/timeconst.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/ktime.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/timekeeping.h \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/clocksource_ids.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/seqlock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/mutex.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/debug_locks.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/mmu.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/RT_MUTEXES) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/CPU_SUP_INTEL) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/CPU_FREQ_TIMES) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/KEYS) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/RETHOOK) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/RV) \
    $(wildcard include/config/ARCH_TASK_STRUCT_ON_STACK) \
    $(wildcard include/config/PREEMPT_NONE) \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/DEBUG_RSEQ) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/sched.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/pid.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/sem.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/sem.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/ipc.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/uidgid.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/highuid.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rhashtable-types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/ipc.h \
  arch/arm64/include/generated/uapi/asm/ipcbuf.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/ipcbuf.h \
  arch/arm64/include/generated/uapi/asm/sembuf.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/sembuf.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/shm.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/shm.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/hugetlb_encode.h \
  arch/arm64/include/generated/uapi/asm/shmbuf.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/shmbuf.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/shmparam.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/shmparam.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kmsan_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/plist.h \
    $(wildcard include/config/DEBUG_PLIST) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/hrtimer_defs.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/timerqueue.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/seccomp.h \
    $(wildcard include/config/SECCOMP) \
    $(wildcard include/config/HAVE_ARCH_SECCOMP_FILTER) \
    $(wildcard include/config/SECCOMP_FILTER) \
    $(wildcard include/config/CHECKPOINT_RESTORE) \
    $(wildcard include/config/SECCOMP_CACHE_DEBUG) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/seccomp.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/seccomp.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/unistd.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/unistd.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/unistd.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/seccomp.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/unistd.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/nodemask.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/resource.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/resource.h \
  arch/arm64/include/generated/uapi/asm/resource.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/resource.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/resource.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/latencytop.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/sched/prio.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/sched/types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/signal.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/signal.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/signal.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/signal.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/signal.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/signal-defs.h \
  arch/arm64/include/generated/uapi/asm/siginfo.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/siginfo.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/syscall_user_dispatch.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/posix-timers.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/rseq.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kcsan.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rv.h \
    $(wildcard include/config/RV_REACTORS) \
  arch/arm64/include/generated/asm/kmap_size.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/pgtable-prot.h \
    $(wildcard include/config/ARM64_BTI_KERNEL) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/tlbflush.h \
    $(wildcard include/config/ARM64_WORKAROUND_REPEAT_TLBI) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/fixmap.h \
    $(wildcard include/config/ACPI_APEI_GHES) \
    $(wildcard include/config/ARM_SDE_INTERFACE) \
    $(wildcard include/config/UNMAP_KERNEL_AT_EL0) \
    $(wildcard include/config/RELOCATABLE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/boot.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/fixmap.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/page_table_check.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/android_erratum_pgtable.h \
    $(wildcard include/config/ANDROID_ARM64_WORKAROUND_DMA_BEYOND_POC) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/pgtable_uffd.h \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
  arch/arm64/include/generated/asm/early_ioremap.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/early_ioremap.h \
    $(wildcard include/config/GENERIC_EARLY_IOREMAP) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/io.h \
    $(wildcard include/config/GENERIC_IOMAP) \
    $(wildcard include/config/TRACE_MMIO_ACCESS) \
    $(wildcard include/config/GENERIC_IOREMAP) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/NO_GENERIC_PCI_IOPORT_MAP) \
    $(wildcard include/config/GENERIC_PCI_IOMAP) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/tracepoint-defs.h \
    $(wildcard include/config/TRACEPOINTS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/logic_pio.h \
    $(wildcard include/config/INDIRECT_PIO) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/fwnode.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/vmalloc.h \
    $(wildcard include/config/KASAN_VMALLOC) \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMALLOC) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/vmalloc.h \
    $(wildcard include/config/PTDUMP_DEBUGFS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/notifier.h \
    $(wildcard include/config/TREE_SRCU) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/SRCU) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rcu_segcblist.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/srcutree.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_ipi.h \
    $(wildcard include/config/MTK_QOS_MT6893) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_common.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/sspm/v3/sspm_define.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/sspm/v3/sspm_reservedmem.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/sspm/v3/sspm_reservedmem_define.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include/soc/mediatek/dramc.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include/soc/mediatek/emi.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/irqreturn.h \

/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o: $(deps_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o)

$(deps_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/qos/mtk_qos_bound.o):
#SYMVER get_qos_bound_count 0xab602512
#SYMVER get_qos_bound_buf 0x9316458a
#SYMVER get_qos_bound 0x7bf94eb3
#SYMVER get_qos_bound_bw_threshold 0x37b9d804
#SYMVER get_qos_bound_idx 0xdb27589c
#SYMVER register_qos_notifier 0x8d51523d
#SYMVER unregister_qos_notifier 0x296ad333
#SYMVER get_qos_bound_apubw_mon 0xcfca06ca
#SYMVER get_qos_bound_apulat_mon 0x82dc0e13
#SYMVER get_qos_bound_emibw_mon 0x703de9f9
#SYMVER get_qos_bound_smibw_mon 0xbf6bc494
