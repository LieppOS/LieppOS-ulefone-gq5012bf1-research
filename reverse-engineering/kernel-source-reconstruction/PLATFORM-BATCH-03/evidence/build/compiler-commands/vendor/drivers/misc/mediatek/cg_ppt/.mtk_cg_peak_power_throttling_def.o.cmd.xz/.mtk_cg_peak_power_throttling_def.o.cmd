cmd_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o := clang -Wp,-MMD,/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/.mtk_cg_peak_power_throttling_def.o.d -nostdinc -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include -I./arch/arm64/include/generated -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include -I./include -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi -I./arch/arm64/include/generated/uapi -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi -I./include/generated/uapi -include /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler-version.h -include /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kconfig.h -include /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DKASAN_SHADOW_SCALE_SHIFT= -Qunused-arguments -fmacro-prefix-map=/home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/= -Wall -Wundef -Werror=strict-prototypes -Wno-trigraphs -fno-strict-aliasing -fno-common -fshort-wchar -fno-PIE -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Wno-format-security -std=gnu11 --target=aarch64-linux-gnu -fintegrated-as -Werror=unknown-warning-option -Werror=ignored-optimization-argument -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -fasynchronous-unwind-tables -mbranch-protection=pac-ret -Wa,-march=armv8.5-a -DARM64_ASM_ARCH='"armv8.5-a"' -ffixed-x18 -DKASAN_SHADOW_SCALE_SHIFT= -fno-delete-null-pointer-checks -Wno-frame-address -Wno-address-of-packed-member -O2 -Wframe-larger-than=2048 -fstack-protector-strong -Wno-gnu -Wno-unused-but-set-variable -Wno-unused-const-variable -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fsanitize=kcfi -Wvla -Wno-pointer-sign -Wcast-function-type -Werror -Wimplicit-fallthrough -fno-strict-overflow -fno-stack-check -Werror=date-time -Werror=incompatible-pointer-types -Wno-initializer-overrides -Wno-sign-compare -Wno-pointer-to-enum-cast -Wno-tautological-constant-out-of-range-compare -Wno-unaligned-access -Wno-cast-function-type-strict -Wno-enum-compare-conditional -Wno-enum-enum-conversion -g -gdwarf-4 -D__ANDROID_COMMON_KERNEL__ -faddrsig -fmacro-prefix-map=/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/=../kernel_device_modules-6.1/ -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1592 -Werror -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/include/uapi -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/ -I/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/gpu/mediatek/mt-plat/  -fsanitize=array-bounds -fsanitize=local-bounds -fsanitize-undefined-trap-on-error  -DMODULE  -DKBUILD_BASENAME='"mtk_cg_peak_power_throttling_def"' -DKBUILD_MODNAME='"mtk_cg_peak_power_throttling"' -D__KBUILD_MODNAME=kmod_mtk_cg_peak_power_throttling -c -o /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.c  

source_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o := /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.c

deps_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o := \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler_attributes.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler-clang.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/CLANG_VERSION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/compiler.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/FTRACE_MCOUNT_RECORD) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/stdarg.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/align.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/const.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/const.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/const.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/limits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/limits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/types.h \
  arch/arm64/include/generated/uapi/asm/types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/int-ll64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/int-ll64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/bitsperlong.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/posix_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/stddef.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/stddef.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/posix_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/posix_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/limits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/stringify.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
    $(wildcard include/config/MODULES) \
    $(wildcard include/config/TRIM_UNUSED_KSYMS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/rwonce.h \
    $(wildcard include/config/LTO) \
    $(wildcard include/config/AS_HAS_LDAPR) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/rwonce.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/linkage.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/container_of.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/build_bug.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/err.h \
  arch/arm64/include/generated/uapi/asm/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/errno-base.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bitops.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/vdso/bits.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/typecheck.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/kernel.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/sysinfo.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/generic-non-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/barrier.h \
    $(wildcard include/config/ARM64_PSEUDO_NMI) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/barrier.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/bitops.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-__ffs.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-ffs.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-__fls.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/builtin-fls.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/ffz.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/fls64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/sched.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/hweight.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/arch_hweight.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/const_hweight.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/cmpxchg.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/lse.h \
    $(wildcard include/config/ARM64_LSE_ATOMICS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/atomic_ll_sc.h \
    $(wildcard include/config/CC_HAS_K_CONSTRAINT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/alternative.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/alternative-macros.h \
  arch/arm64/include/generated/asm/cpucaps.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/insn-def.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/brk-imm.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/init.h \
    $(wildcard include/config/STRICT_KERNEL_RWX) \
    $(wildcard include/config/STRICT_MODULE_RWX) \
    $(wildcard include/config/LTO_CLANG) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/atomic_lse.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic/atomic-long.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/atomic/atomic-instrumented.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/instrumented.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kmsan-checks.h \
    $(wildcard include/config/KMSAN) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/instrumented-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/lock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/instrumented-lock.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/non-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/non-instrumented-non-atomic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/le.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/byteorder.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/byteorder/little_endian.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/byteorder/little_endian.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/swab.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/swab.h \
  arch/arm64/include/generated/uapi/asm/swab.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/swab.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/byteorder/generic.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kstrtox.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/math.h \
  arch/arm64/include/generated/asm/div64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/div64.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/minmax.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/kern_levels.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/ratelimit_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/param.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/uapi/asm/param.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/asm-generic/param.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/spinlock_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/qrwlock_types.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/once_lite.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/instruction_pointer.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/errno.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/overflow.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/uapi/linux/string.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/string.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/fortify-string.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/bug.h \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/common/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_plat_kl.h \

/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o: $(deps_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o)

$(deps_/home/armol/kernel-work/platform-batch-03-cleancheck/ws/src/kdm/drivers/misc/mediatek/cg_ppt/mtk_cg_peak_power_throttling_def.o):
